import { useState, useEffect } from "react";
import { Project, Task } from "@shared/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, LogOut, Settings, MoreHorizontal, Check, Clock, AlertCircle, CheckCircle2 } from "lucide-react";
import { Link } from "react-router-dom";

export default function Dashboard() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNewProjectModal, setShowNewProjectModal] = useState(false);
  const [newProjectName, setNewProjectName] = useState("");

  useEffect(() => {
    // Fetch projects
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      const response = await fetch("/api/projects");
      if (response.ok) {
        const data = await response.json();
        setProjects(data);
        if (data.length > 0) {
          setSelectedProject(data[0]);
          fetchTasks(data[0].id);
        }
      }
    } catch (error) {
      console.error("Error fetching projects:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchTasks = async (projectId: string) => {
    try {
      const response = await fetch(`/api/projects/${projectId}/tasks`);
      if (response.ok) {
        const data = await response.json();
        setTasks(data);
      }
    } catch (error) {
      console.error("Error fetching tasks:", error);
    }
  };

  const createProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjectName.trim()) return;

    try {
      const response = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newProjectName }),
      });

      if (response.ok) {
        setNewProjectName("");
        setShowNewProjectModal(false);
        fetchProjects();
      }
    } catch (error) {
      console.error("Error creating project:", error);
    }
  };

  const getStatusIcon = (status: Task["status"]) => {
    switch (status) {
      case "todo":
        return <AlertCircle className="w-4 h-4 text-gray-400" />;
      case "in-progress":
        return <Clock className="w-4 h-4 text-blue-500" />;
      case "review":
        return <Check className="w-4 h-4 text-purple-500" />;
      case "done":
        return <CheckCircle2 className="w-4 h-4 text-green-500" />;
    }
  };

  const getStatusColor = (status: Task["status"]) => {
    switch (status) {
      case "todo":
        return "bg-gray-100 text-gray-800";
      case "in-progress":
        return "bg-blue-100 text-blue-800";
      case "review":
        return "bg-purple-100 text-purple-800";
      case "done":
        return "bg-green-100 text-green-800";
    }
  };

  const getPriorityColor = (priority: Task["priority"]) => {
    switch (priority) {
      case "low":
        return "text-gray-500";
      case "medium":
        return "text-yellow-600";
      case "high":
        return "text-red-600";
    }
  };

  const tasksByStatus = {
    todo: tasks.filter((t) => t.status === "todo"),
    "in-progress": tasks.filter((t) => t.status === "in-progress"),
    review: tasks.filter((t) => t.status === "review"),
    done: tasks.filter((t) => t.status === "done"),
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
          <p className="mt-4 text-gray-600">Loading your projects...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-64 bg-gray-900 text-white flex flex-col">
        <div className="p-6 border-b border-gray-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center">
              <span className="text-white font-bold">P</span>
            </div>
            <span className="font-bold text-lg">ProjectHub</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          <div className="mb-6">
            <h3 className="text-xs font-semibold text-gray-400 uppercase mb-4">Projects</h3>
            <div className="space-y-2">
              {projects.map((project) => (
                <button
                  key={project.id}
                  onClick={() => {
                    setSelectedProject(project);
                    fetchTasks(project.id);
                  }}
                  className={`w-full text-left px-4 py-2 rounded-lg transition ${
                    selectedProject?.id === project.id
                      ? "bg-purple-600"
                      : "hover:bg-gray-800"
                  }`}
                >
                  <p className="font-medium truncate">{project.name}</p>
                  <p className="text-xs text-gray-400">
                    {project.members.length} members
                  </p>
                </button>
              ))}
            </div>
          </div>

          <Button
            onClick={() => setShowNewProjectModal(true)}
            className="w-full bg-purple-600 hover:bg-purple-700 gap-2"
          >
            <Plus className="w-4 h-4" />
            New Project
          </Button>
        </div>

        <div className="border-t border-gray-800 p-4 space-y-2">
          <Button variant="ghost" className="w-full justify-start gap-2 text-gray-300">
            <Settings className="w-4 h-4" />
            Settings
          </Button>
          <Link to="/">
            <Button variant="ghost" className="w-full justify-start gap-2 text-gray-300">
              <LogOut className="w-4 h-4" />
              Sign Out
            </Button>
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                {selectedProject?.name || "Projects"}
              </h1>
              {selectedProject && (
                <p className="text-gray-600 mt-1">{selectedProject.description}</p>
              )}
            </div>
            <Button className="bg-purple-600 hover:bg-purple-700 gap-2">
              <Plus className="w-4 h-4" />
              New Task
            </Button>
          </div>
        </div>

        {/* Board */}
        {selectedProject ? (
          <div className="flex-1 overflow-x-auto p-8">
            <div className="grid grid-cols-4 gap-6 min-w-max">
              {[
                { key: "todo", label: "To Do", color: "bg-gray-100" },
                { key: "in-progress", label: "In Progress", color: "bg-blue-100" },
                { key: "review", label: "Review", color: "bg-purple-100" },
                { key: "done", label: "Done", color: "bg-green-100" },
              ].map(({ key, label, color }) => (
                <div key={key} className="w-80">
                  <div className={`${color} rounded-lg p-4 mb-4`}>
                    <h2 className="font-semibold text-gray-900">
                      {label}{" "}
                      <span className="text-sm font-normal text-gray-600">
                        ({tasksByStatus[key as keyof typeof tasksByStatus].length})
                      </span>
                    </h2>
                  </div>

                  <div className="space-y-3">
                    {tasksByStatus[key as keyof typeof tasksByStatus].map((task) => (
                      <div
                        key={task.id}
                        className="bg-white rounded-lg border border-gray-200 p-4 hover:shadow-md transition cursor-pointer"
                      >
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="font-medium text-gray-900 flex-1">
                            {task.title}
                          </h3>
                          <button className="text-gray-400 hover:text-gray-600">
                            <MoreHorizontal className="w-4 h-4" />
                          </button>
                        </div>

                        <p className="text-sm text-gray-600 mb-3">
                          {task.description}
                        </p>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            {getStatusIcon(task.status)}
                            <span
                              className={`text-xs px-2 py-1 rounded-full font-medium ${getStatusColor(
                                task.status
                              )}`}
                            >
                              {task.status}
                            </span>
                          </div>
                          <span
                            className={`text-xs font-medium ${getPriorityColor(
                              task.priority
                            )}`}
                          >
                            {task.priority}
                          </span>
                        </div>

                        {task.assignee && (
                          <div className="mt-3 pt-3 border-t border-gray-200">
                            <p className="text-xs text-gray-600">
                              Assigned to{" "}
                              <span className="font-medium">
                                {task.assignee.name}
                              </span>
                            </p>
                          </div>
                        )}
                      </div>
                    ))}

                    <button className="w-full p-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-500 hover:border-gray-400 hover:text-gray-600 transition">
                      <Plus className="w-4 h-4 mx-auto" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <p className="text-gray-600 mb-4">No projects yet</p>
              <Button
                onClick={() => setShowNewProjectModal(true)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                Create Your First Project
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* New Project Modal */}
      {showNewProjectModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg border border-gray-200 max-w-md w-full p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Create New Project
            </h2>
            <form onSubmit={createProject} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Project Name
                </label>
                <Input
                  type="text"
                  placeholder="My Awesome Project"
                  value={newProjectName}
                  onChange={(e) => setNewProjectName(e.target.value)}
                  autoFocus
                />
              </div>
              <div className="flex gap-3">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={() => setShowNewProjectModal(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="flex-1 bg-purple-600 hover:bg-purple-700"
                >
                  Create
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
