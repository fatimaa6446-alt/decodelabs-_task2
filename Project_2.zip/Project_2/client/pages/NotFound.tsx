import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Home, MessageSquare } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 flex items-center justify-center px-4">
      <div className="max-w-md w-full text-center">
        <div className="mb-6">
          <h1 className="text-6xl font-bold text-purple-600 mb-4">404</h1>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Page not found</h2>
          <p className="text-gray-600">
            The page you're looking for doesn't exist yet or has been removed.
          </p>
        </div>

        {location.pathname !== "/" && location.pathname !== "/dashboard" && (
          <div className="mb-8 p-4 bg-white rounded-lg border border-gray-200">
            <p className="text-sm text-gray-600 mb-2">Currently viewing:</p>
            <p className="font-mono text-purple-600">{location.pathname}</p>
          </div>
        )}

        <div className="space-y-3">
          <Link to="/" className="block">
            <Button className="w-full bg-purple-600 hover:bg-purple-700 gap-2">
              <Home className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
          <Link to="/dashboard" className="block">
            <Button variant="outline" className="w-full gap-2">
              Go to Dashboard
            </Button>
          </Link>
        </div>

        <div className="mt-8 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex gap-2 mb-2 text-blue-900">
            <MessageSquare className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <p className="text-sm font-medium">Want to build this page?</p>
          </div>
          <p className="text-xs text-blue-800">
            Use the chat to describe what you'd like on this page and we'll create it for you.
          </p>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
