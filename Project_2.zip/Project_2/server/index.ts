import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import { handleSignup, handleLogin, handleLogout } from "./routes/auth";
import {
  getProjects,
  createProject,
  getProjectById,
  updateProject,
  deleteProject,
} from "./routes/projects";
import {
  getProjectTasks,
  createTask,
  updateTask,
  deleteTask,
} from "./routes/tasks";
import {
  getTaskComments,
  createComment,
  updateComment,
  deleteComment,
} from "./routes/comments";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Auth routes
  app.post("/api/auth/signup", handleSignup);
  app.post("/api/auth/login", handleLogin);
  app.post("/api/auth/logout", handleLogout);

  // Project routes
  app.get("/api/projects", getProjects);
  app.post("/api/projects", createProject);
  app.get("/api/projects/:projectId", getProjectById);
  app.put("/api/projects/:projectId", updateProject);
  app.delete("/api/projects/:projectId", deleteProject);

  // Task routes
  app.get("/api/projects/:projectId/tasks", getProjectTasks);
  app.post("/api/projects/:projectId/tasks", createTask);
  app.put("/api/tasks/:taskId", updateTask);
  app.delete("/api/tasks/:taskId", deleteTask);

  // Comment routes
  app.get("/api/tasks/:taskId/comments", getTaskComments);
  app.post("/api/tasks/:taskId/comments", createComment);
  app.put("/api/comments/:commentId", updateComment);
  app.delete("/api/comments/:commentId", deleteComment);

  // Example API routes (keep for compatibility)
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);

  return app;
}
