import { RequestHandler } from "express";
import { Comment, User } from "@shared/api";
import { getTask } from "./tasks";

// In-memory comment storage
const comments: Map<string, Comment> = new Map();
const commentIdCounter = { count: 1 };

// Sample user
const sampleUser: User = {
  id: "user-1",
  name: "John Doe",
  email: "john@example.com",
};

// Sample comments
comments.set("comment-1", {
  id: "comment-1",
  taskId: "task-1",
  author: sampleUser,
  content: "Let's make sure this looks great on mobile devices",
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
});

export const getTaskComments: RequestHandler = (req, res) => {
  const { taskId } = req.params;

  // Verify task exists
  if (!getTask(taskId)) {
    res.status(404).json({ error: "Task not found" });
    return;
  }

  const taskComments = Array.from(comments.values()).filter(
    (comment) => comment.taskId === taskId
  );

  res.status(200).json(taskComments);
};

export const createComment: RequestHandler = (req, res) => {
  const { taskId } = req.params;
  const { content } = req.body;

  if (!content) {
    res.status(400).json({ error: "Comment content is required" });
    return;
  }

  if (!getTask(taskId)) {
    res.status(404).json({ error: "Task not found" });
    return;
  }

  const commentId = `comment-${commentIdCounter.count++}`;
  const comment: Comment = {
    id: commentId,
    taskId,
    author: sampleUser,
    content,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  comments.set(commentId, comment);
  res.status(201).json(comment);
};

export const updateComment: RequestHandler = (req, res) => {
  const { commentId } = req.params;
  const { content } = req.body;

  const comment = comments.get(commentId);
  if (!comment) {
    res.status(404).json({ error: "Comment not found" });
    return;
  }

  comment.content = content || comment.content;
  comment.updatedAt = new Date().toISOString();

  comments.set(commentId, comment);
  res.status(200).json(comment);
};

export const deleteComment: RequestHandler = (req, res) => {
  const { commentId } = req.params;

  if (!comments.has(commentId)) {
    res.status(404).json({ error: "Comment not found" });
    return;
  }

  comments.delete(commentId);
  res.status(204).send();
};

export const getAllComments = () => comments;
