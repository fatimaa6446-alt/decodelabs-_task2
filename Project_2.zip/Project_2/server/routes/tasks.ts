import { RequestHandler } from "express";
import { Task, User } from "@shared/api";
import { getAllProjects } from "./projects";

// In-memory task storage
const tasks: Map<string, Task> = new Map();
const taskIdCounter = { count: 1 };

// Sample data
const sampleUser: User = {
  id: "user-1",
  name: "John Doe",
  email: "john@example.com",
};

// Initialize with sample tasks
tasks.set("task-1", {
  id: "task-1",
  projectId: "project-1",
  title: "Design homepage mockup",
  description: "Create high-fidelity mockups for the new homepage",
  status: "in-progress",
  priority: "high",
  assignee: sampleUser,
  dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
});

tasks.set("task-2", {
  id: "task-2",
  projectId: "project-1",
  title: "Setup development environment",
  description: "Install dependencies and configure build tools",
  status: "done",
  priority: "high",
  assignee: sampleUser,
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
});

tasks.set("task-3", {
  id: "task-3",
  projectId: "project-1",
  title: "Review design with stakeholders",
  description: "Present mockups and gather feedback from the team",
  status: "review",
  priority: "medium",
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
});

tasks.set("task-4", {
  id: "task-4",
  projectId: "project-1",
  title: "Implement responsive CSS",
  description: "Make the design mobile-friendly and responsive",
  status: "todo",
  priority: "medium",
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
});

export const getProjectTasks: RequestHandler = (req, res) => {
  const { projectId } = req.params;

  // Verify project exists
  if (!getAllProjects().has(projectId)) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const projectTasks = Array.from(tasks.values()).filter(
    (task) => task.projectId === projectId
  );

  res.status(200).json(projectTasks);
};

export const createTask: RequestHandler = (req, res) => {
  const { projectId } = req.params;
  const { title, description, status = "todo", priority = "medium", assigneeId } = req.body;

  if (!title) {
    res.status(400).json({ error: "Task title is required" });
    return;
  }

  if (!getAllProjects().has(projectId)) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const taskId = `task-${taskIdCounter.count++}`;
  const task: Task = {
    id: taskId,
    projectId,
    title,
    description: description || "",
    status: status || "todo",
    priority: priority || "medium",
    assignee: assigneeId ? sampleUser : undefined,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  tasks.set(taskId, task);
  res.status(201).json(task);
};

export const updateTask: RequestHandler = (req, res) => {
  const { taskId } = req.params;
  const { title, description, status, priority, assigneeId, dueDate } = req.body;

  const task = tasks.get(taskId);
  if (!task) {
    res.status(404).json({ error: "Task not found" });
    return;
  }

  task.title = title || task.title;
  task.description = description !== undefined ? description : task.description;
  task.status = status || task.status;
  task.priority = priority || task.priority;
  task.assignee = assigneeId ? sampleUser : task.assignee;
  task.dueDate = dueDate || task.dueDate;
  task.updatedAt = new Date().toISOString();

  tasks.set(taskId, task);
  res.status(200).json(task);
};

export const deleteTask: RequestHandler = (req, res) => {
  const { taskId } = req.params;

  if (!tasks.has(taskId)) {
    res.status(404).json({ error: "Task not found" });
    return;
  }

  tasks.delete(taskId);
  res.status(204).send();
};

export const getTask = (id: string) => tasks.get(id);
export const getAllTasks = () => tasks;
