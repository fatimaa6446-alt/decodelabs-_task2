import { RequestHandler } from "express";
import { Project, User } from "@shared/api";

// In-memory project storage
const projects: Map<string, Project> = new Map();
const projectIdCounter = { count: 1 };

// Sample data
const sampleUser: User = {
  id: "user-1",
  name: "John Doe",
  email: "john@example.com",
};

// Initialize with sample project
projects.set("project-1", {
  id: "project-1",
  name: "Website Redesign",
  description: "Complete redesign of the company website",
  members: [sampleUser],
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
});

export const getProjects: RequestHandler = (req, res) => {
  const projectList = Array.from(projects.values());
  res.status(200).json(projectList);
};

export const createProject: RequestHandler = (req, res) => {
  const { name, description } = req.body;

  if (!name) {
    res.status(400).json({ error: "Project name is required" });
    return;
  }

  const projectId = `project-${projectIdCounter.count++}`;
  const project: Project = {
    id: projectId,
    name,
    description: description || "",
    members: [sampleUser],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  projects.set(projectId, project);
  res.status(201).json(project);
};

export const getProjectById: RequestHandler = (req, res) => {
  const { projectId } = req.params;
  const project = projects.get(projectId);

  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  res.status(200).json(project);
};

export const updateProject: RequestHandler = (req, res) => {
  const { projectId } = req.params;
  const { name, description } = req.body;

  const project = projects.get(projectId);
  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  project.name = name || project.name;
  project.description = description !== undefined ? description : project.description;
  project.updatedAt = new Date().toISOString();

  projects.set(projectId, project);
  res.status(200).json(project);
};

export const deleteProject: RequestHandler = (req, res) => {
  const { projectId } = req.params;

  if (!projects.has(projectId)) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  projects.delete(projectId);
  res.status(204).send();
};

export const getProject = (id: string) => projects.get(id);
export const getAllProjects = () => projects;
