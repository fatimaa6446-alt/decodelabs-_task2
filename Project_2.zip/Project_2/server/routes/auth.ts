import { RequestHandler } from "express";
import { AuthResponse, User } from "@shared/api";

// In-memory user storage (replace with database in production)
const users: Map<string, User & { password: string }> = new Map();
const sessions: Map<string, User> = new Map();

export const handleSignup: RequestHandler = (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    res.status(400).json({
      success: false,
      message: "Missing required fields",
    } as AuthResponse);
    return;
  }

  if (users.has(email)) {
    res.status(400).json({
      success: false,
      message: "User already exists",
    } as AuthResponse);
    return;
  }

  const user: User & { password: string } = {
    id: Date.now().toString(),
    name,
    email,
    password, // In production, hash this!
  };

  users.set(email, user);
  sessions.set(user.id, { id: user.id, name, email });

  res.status(201).json({
    success: true,
    user: { id: user.id, name, email },
  } as AuthResponse);
};

export const handleLogin: RequestHandler = (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    res.status(400).json({
      success: false,
      message: "Missing email or password",
    } as AuthResponse);
    return;
  }

  const user = users.get(email);

  if (!user || user.password !== password) {
    res.status(401).json({
      success: false,
      message: "Invalid email or password",
    } as AuthResponse);
    return;
  }

  sessions.set(user.id, { id: user.id, name: user.name, email: user.email });

  res.status(200).json({
    success: true,
    user: { id: user.id, name: user.name, email: user.email },
  } as AuthResponse);
};

export const handleLogout: RequestHandler = (req, res) => {
  const userId = req.headers["x-user-id"] as string;
  if (userId) {
    sessions.delete(userId);
  }
  res.status(200).json({ success: true });
};

export const getSession = (userId: string) => sessions.get(userId);
export const getAllUsers = () => Array.from(users.values()).map(({ password, ...u }) => u);
